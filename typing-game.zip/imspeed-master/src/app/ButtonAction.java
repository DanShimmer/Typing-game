package app;

import javafx.scene.layout.Pane;

public interface ButtonAction {
	void callback(Pane root, boolean active);
}
